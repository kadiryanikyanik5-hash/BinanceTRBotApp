
BINANCE TR BOT ANDROID - KAYNAK PROJESİ

ÖNEMLİ: Bu ZIP henüz APK değildir. APK, GitHub Actions üzerinden derlenir.

1) ZIP'i bir bilgisayara veya GitHub'a yükle; GitHub'da yeni private repository açman önerilir.
2) Bu klasördeki dosyaları repository'nin köküne yükle/commit et.
3) GitHub > Actions > Build Android APK > Run workflow seç.
4) İşlem tamamlanınca BinanceTRBot-debug-apk artifact'ini indir; içindeki app-debug.apk dosyasını telefona alıp kur.

Telefon üzerinden GitHub kullanıyorsan tarayıcıda github.com açıp yeni PRIVATE repository oluşturabilir, ZIP içindeki dosyaları yükleyebilirsin. APK üretmek için Actions çalıştırılmalıdır.

UYGULAMA
- API Key ve Secret uygulama içinden girilir; APK içine gömülmez.
- Ayarlar uygulamanın özel dosya alanında saklanır. Yine de telefon kilidini koru ve API anahtarını başka yere paylaşma.
- Binance TR API anahtarında para çekme yetkisi kapalı olmalıdır. Kod para çekme endpoint'i çağırmaz.
- İlk çalıştırmayı gerçek işlem kapalıyken yap. Gerçek işlem kutusu işaretlenirse gerçek emirler gönderilebilir ve zarar mümkündür.
- 50-150 TL sınırı uygulamada ayarlanmıştır; mevcut strateji kâr garantisi vermez.
- Botun durdurma isteği sonraki döngü/coin kontrolünde işlenebilir; bir API isteği sürerken anında kesilmeyebilir.

TEKNİK
Android Studio/Gradle + Chaquopy (Python 3.11), GitHub Actions build workflow.
Bu kaynak, APK kurulup gerçek hesapta işlem yapmadan önce mutlaka test edilmelidir.
\n\nGÜNCELLEME: Bot sabit 20 coin listesi kullanmaz. Binance TR'deki aktif TRY kotasyonlu spot paritelerini otomatik keşfeder ve 24 saatlik TRY hacmine göre tarama sırası oluşturur. Kaldıraçlı UP/DOWN/BULL/BEAR tokenları hariç tutulur. Bu strateji kâr garantisi vermez. API anahtarında para çekme iznini kapalı tutun.\n