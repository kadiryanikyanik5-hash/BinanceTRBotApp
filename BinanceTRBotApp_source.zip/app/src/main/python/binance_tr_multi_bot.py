import json
import time
import builtins
from decimal import Decimal, ROUND_DOWN
from pathlib import Path

from binance_tr_auto_bot import (
    read_json, request_json, market_data, account, unwrap_data,
    market_order, order_detail, wait_order, MARKET_BASE
)

ROOT = Path.home() / "binancebot"
CFG_FILE = ROOT / "bot_config.json"
STATE_FILE = ROOT / "multi_bot_state.json"
LOG_FILE = ROOT / "bot.log"

def set_home(path):
    global ROOT, CFG_FILE, STATE_FILE, LOG_FILE
    ROOT = Path(path)
    ROOT.mkdir(parents=True, exist_ok=True)
    CFG_FILE = ROOT / "bot_config.json"
    STATE_FILE = ROOT / "multi_bot_state.json"
    LOG_FILE = ROOT / "bot.log"

def _log(*args, **kwargs):
    text = " ".join(str(x) for x in args)
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(text + "\n")
    builtins.print(*args, **kwargs)

print = _log

# Pariteler Binance TR piyasa bilgisinden dinamik keşfedilir; sabit 20 coin listesi yok.
LEVERAGED_SUFFIXES = ("UP", "DOWN", "BULL", "BEAR")

def D(x):
    try:
        return Decimal(str(x))
    except Exception:
        return Decimal("0")

def load_state():
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {"positions": {}, "spent_tl": "0"}

def save_state(s):
    STATE_FILE.write_text(json.dumps(s, indent=2))

def balances(cfg):
    r = unwrap_data(account(cfg))
    if not isinstance(r, dict):
        raise RuntimeError("Hesap yanıtı okunamadı.")
    return {
        str(a.get("asset", "")).upper(): D(a.get("free", "0"))
        for a in r.get("accountAssets", [])
        if isinstance(a, dict)
    }

def available_pairs():
    """Aktif, spot işlemi açık ve TRY kotasyonlu tüm pariteleri keşfet."""
    r = request_json("/api/v3/exchangeInfo", {}, base=MARKET_BASE)
    data = r.get("symbols", r.get("data", [])) if isinstance(r, dict) else r
    if isinstance(data, dict):
        data = data.get("symbols", [])
    found = set()
    for item in data if isinstance(data, list) else []:
        if not isinstance(item, dict):
            continue
        symbol = str(item.get("symbol", "")).upper().replace("_", "")
        quote = str(item.get("quoteAsset", "")).upper()
        status = str(item.get("status", "TRADING")).upper()
        is_try = quote == "TRY" or (not quote and symbol.endswith("TRY"))
        if not is_try or not symbol.endswith("TRY") or status != "TRADING":
            continue
        if item.get("isSpotTradingAllowed") is False:
            continue
        base_asset = str(item.get("baseAsset", symbol[:-3])).upper()
        if base_asset.endswith(LEVERAGED_SUFFIXES):
            continue
        found.add(base_asset + "_TRY")

    if not found:
        raise RuntimeError("Binance TR'de aktif TRY spot paritesi bulunamadı.")

    # Hacmi yüksek piyasalar önce taranır; liste sınırlandırılmaz.
    try:
        tickers = request_json("/api/v3/ticker/24hr", {}, base=MARKET_BASE)
        if isinstance(tickers, dict):
            tickers = tickers.get("data", tickers.get("symbols", []))
        volume = {}
        for t in tickers if isinstance(tickers, list) else []:
            if isinstance(t, dict):
                compact = str(t.get("symbol", "")).upper().replace("_", "")
                if compact.endswith("TRY"):
                    try:
                        volume[compact[:-3] + "_TRY"] = D(t.get("quoteVolume", "0"))
                    except Exception:
                        pass
        return sorted(found, key=lambda pair: volume.get(pair, D("0")), reverse=True)
    except Exception as e:
        print("24 saatlik hacim sıralaması alınamadı; pariteler alfabetik taranacak:", e)
        return sorted(found)

def order_id(result):
    if isinstance(result, dict):
        for k in ("orderId", "order_id", "id"):
            if result.get(k) is not None:
                return result[k]
        for k in ("data", "result", "order"):
            found = order_id(result.get(k))
            if found is not None:
                return found
    return None

def rules(symbol):
    r = request_json("/api/v3/exchangeInfo", {}, base=MARKET_BASE)
    data = r.get("symbols", r.get("data", [])) if isinstance(r, dict) else r
    if isinstance(data, dict):
        data = data.get("symbols", [])
    target = symbol.replace("_", "")
    for item in data:
        if isinstance(item, dict) and item.get("symbol") == target:
            filters = {f.get("filterType"): f for f in item.get("filters", [])}
            lot = filters.get("LOT_SIZE", {})
            return D(lot.get("stepSize", "1")), D(
                filters.get("NOTIONAL", {}).get("minNotional", "10")
            )
    raise RuntimeError(f"{symbol} emir kuralları bulunamadı.")

def rounded_qty(qty, step):
    if step <= 0:
        return qty
    return (qty / step).to_integral_value(rounding=ROUND_DOWN) * step

def main():
    cfg = read_json(str(CFG_FILE), {})
    if not cfg:
        raise RuntimeError("bot_config.json okunamadı.")

    trade_tl = D(cfg.get("trade_tl", "50"))
    min_tl = D(cfg.get("min_tl", "50"))
    max_tl = D(cfg.get("max_tl", "150"))
    buy_pct = D(cfg.get("buy_threshold_percent", "0.10"))
    sell_pct = D(cfg.get("sell_threshold_percent", "0.10"))

    if trade_tl < min_tl or trade_tl <= 0 or max_tl < trade_tl:
        raise RuntimeError("trade_tl, min_tl ve max_tl ayarlarını kontrol et.")

    watch = available_pairs()
    if not watch:
        raise RuntimeError("Aktif TRY spot paritesi bulunamadı.")

    print("DİNAMİK TRY SPOT TARAMASI —", len(watch), "parite")
    print("Tarama sabit coin listesi kullanmaz; aktif TRY spot paritelerini otomatik keşfeder.")
    print("İşlem tutarı:", trade_tl, "TL | Açık pozisyon bütçe sınırı:", max_tl, "TL")
    print("BONK mevcut bakiyesi SAT sinyalinde değerlendirilebilir.")
    live = bool(cfg.get("live_trading", False))
    if live:
        print("UYGULAMADAN GERÇEK İŞLEM AÇIK. İşlemler zarar edebilir.")
    if not live:
        print("GERÇEK EMİR KAPALI — sadece tarama yapılacak.")
    else:
        print("GERÇEK EMİR AÇIK. İşlemler zarar edebilir.")
        print("API anahtarında para çekme izni kapalı olmalı.")

    while True:
        if (ROOT / "STOP").exists():
            print("Uygulama tarafından durduruldu.")
            break
        try:
            bal = balances(cfg)
            state = load_state()
            pos = state.setdefault("positions", {})
            # Açık bütçe yalnızca halen açık pozisyonlardan hesaplanır.
            # Satıştan sonra bütçe serbest kalır.
            spent = sum(
                (D(p.get("budget_tl", trade_tl)) for p in pos.values()
                 if isinstance(p, dict) and p.get("status") == "OPEN"),
                D("0")
            )

            for symbol in watch:
                if (ROOT / "STOP").exists():
                    print("Durdurma isteği alındı.")
                    return
                local = dict(cfg)
                local["symbol"] = symbol
                asset = symbol.removesuffix("_TRY")

                try:
                    price, ma5, ma15 = market_data(local)
                    diff = (ma5 / ma15 - 1) * 100 if ma15 else D("0")
                    signal = "AL" if diff >= buy_pct else (
                        "SAT" if diff <= -sell_pct else "BEKLE"
                    )
                    print(f"{symbol:10} fiyat={price} fark={diff:.5f}% {signal}")

                    holding = D(bal.get(asset, 0))
                    position = pos.get(symbol)

                    # BONK için önceden var olan kullanılabilir bakiye de satılabilir.
                    # Diğer coinlerde yalnızca botun kaydettiği pozisyonlar satılır.
                    if live and signal == "SAT":
                        if position and position.get("status") == "VERIFY":
                            print("  Emir doğrulanmamış; yeni emir gönderilmiyor.")
                            continue

                        if symbol == "BONK_TRY":
                            if state.get("bonk_25_sold"):
                                print("  BONK %25 satışı daha önce doğrulanmış; tekrar satılmayacak.")
                                continue
                            qty = rounded_qty(holding * D("0.25"), D("1"))
                        elif position and position.get("status") == "OPEN":
                            qty = min(holding, D(position.get("quantity", "0")))
                        else:
                            qty = D("0")

                        if qty <= 0:
                            continue

                        step, min_notional = rules(symbol)
                        qty = rounded_qty(qty, step)
                        if qty <= 0 or qty * price < min_notional:
                            print("  Satış atlandı: miktar veya asgari tutar uygun değil.")
                            continue

                        before = qty
                        result = market_order(local, "SELL", quantity=str(qty))
                        oid = order_id(result)
                        if oid is None:
                            print("  Emir kimliği alınamadı; kontrol etmeden tekrar deneme.")
                            pos[symbol] = {"status": "VERIFY", "note": "Satış emri yanıtı kontrol edilmeli"}
                            save_state(state)
                            return

                        detail = unwrap_data(wait_order(local, oid))
                        status = int(detail.get("status", -99)) if isinstance(detail, dict) else -99
                        executed_qty = D(detail.get("executedQty", "0")) if isinstance(detail, dict) else D("0")
                        executed_quote = D(detail.get("executedQuoteQty", "0")) if isinstance(detail, dict) else D("0")
                        after_bal = balances(cfg).get(asset, D("0"))

                        if status == 2 and executed_qty > 0 and executed_quote > 0 and after_bal < holding:
                            sold_observed = holding - after_bal
                            if symbol == "BONK_TRY":
                                tolerance = max(step * 2, qty * D("0.02"))
                                if abs(sold_observed - qty) > tolerance or abs(executed_qty - qty) > tolerance:
                                    pos[symbol] = {
                                        "status": "VERIFY",
                                        "order_id": str(oid),
                                        "note": "Satış miktarı bakiye değişimiyle uyuşmadı; elle kontrol et"
                                    }
                                    print("  UYARI: Satış miktarı beklenenle uyuşmadı.")
                                    print("  Emir miktarı:", qty, "| Bakiyeden hesaplanan satış:", sold_observed)
                                else:
                                    state["bonk_25_sold"] = True
                                    pos[symbol] = {
                                        "status": "OPEN",
                                        "quantity": str(after_bal),
                                        "note": "Tek seferlik %25 BONK satışı emir ve bakiye ile doğrulandı"
                                    }
                                    print("  BONK satış miktarı bakiye değişimiyle kontrol edildi.")
                                    print("  Emir miktarı:", qty, "| Hesaplanan satış:", sold_observed)
                                    print("  Kalan BONK:", after_bal)
                            elif position and position.get("status") == "OPEN":
                                remaining = max(D("0"), D(position["quantity"]) - sold_observed)
                                if remaining <= 0:
                                    pos.pop(symbol, None)
                                else:
                                    pos[symbol]["quantity"] = str(remaining)
                            print("  Emir durumu:", status)
                        else:
                            print("  Satış kesinleşmedi veya bakiye değişimi doğrulanmadı; durum:", status)
                            pos[symbol] = {
                                "status": "VERIFY",
                                "order_id": str(oid),
                                "note": "Yeni emir göndermeden önce Binance TR emir geçmişinden kontrol et"
                            }
                        save_state(state)
                        return

                    if live and signal == "AL":
                        if position:
                            continue
                        if holding > 0:
                            # Önceden elde bulunan coin için ikinci alım yapma.
                            continue
                        if spent + trade_tl > max_tl:
                            continue
                        if D(bal.get("TRY", 0)) < trade_tl:
                            print("  Alım atlandı: kullanılabilir TRY yetersiz.")
                            continue

                        result = market_order(local, "BUY", quote_tl=str(trade_tl))
                        oid = order_id(result)
                        if oid is None:
                            print("  Alım yanıtında emir kimliği yok; kontrol gerekli.")
                            pos[symbol] = {"status": "VERIFY", "note": "Alım emri kontrol edilmeli"}
                            save_state(state)
                            return

                        detail = unwrap_data(wait_order(local, oid))
                        status = int(detail.get("status", -99)) if isinstance(detail, dict) else -99
                        new_bal = balances(cfg).get(asset, D("0"))
                        if status == 2 and new_bal > 0:
                            pos[symbol] = {
                                "status": "OPEN",
                                "quantity": str(new_bal),
                                "budget_tl": str(trade_tl)
                            }
                            print("  Alım gerçekleşti; miktar hesap bakiyesinden okundu.")
                        else:
                            pos[symbol] = {
                                "status": "VERIFY",
                                "order_id": str(oid),
                                "note": "Alım sonucu kesinleşmedi; tekrar emir gönderme"
                            }
                            print("  Alım sonucu kesinleşmedi; durum:", status)
                        save_state(state)
                        return

                except Exception as e:
                    print(f"  {symbol} hata: {e}")

                time.sleep(0.15)

            save_state(state)
            print("\nTarama tamamlandı; 60 saniye bekleniyor.\n")
            time.sleep(60)

        except KeyboardInterrupt:
            print("\nBot durduruldu.")
            break
        except Exception as e:
            print("Tur hatası:", e)
            time.sleep(15)

if __name__ == "__main__":
    main()
