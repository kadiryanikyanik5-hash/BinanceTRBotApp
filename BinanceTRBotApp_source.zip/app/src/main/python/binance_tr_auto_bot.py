#!/usr/bin/env python3
# Binance TR automatic spot bot — standard library only.
# SAFETY: live trading requires both config live_trading=true and typing ISLEMLERI AC.
# This bot never calls any withdrawal endpoint.

import json, time, hmac, hashlib, urllib.parse, urllib.request, urllib.error
from decimal import Decimal, ROUND_DOWN
from pathlib import Path

BASE = "https://www.binance.tr"
MARKET_BASE = "https://api.binance.me"
CONFIG_FILE = "bot_config.json"
STATE_FILE = "bot_state.json"

DEFAULT_CONFIG = {
    "api_key": "",
    "api_secret": "",
    "symbol": "BTC_TRY",
    "trade_tl": "50",
    "min_tl": "50",
    "max_tl": "150",
    "live_trading": False,
    "check_interval_seconds": 60,
    "buy_threshold_percent": "0.10",
    "sell_threshold_percent": "0.10"
}

def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(default, f, indent=2)
        return dict(default)

def save_json(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2)

def request_json(path, params=None, method="GET", signed=False, cfg=None, base=BASE):
    params = dict(params or {})
    headers = {"User-Agent": "BinanceTR-AutoBot/1.0"}
    if signed:
        if not cfg or not cfg.get("api_key") or not cfg.get("api_secret"):
            raise RuntimeError("API anahtarı/Secret eksik. bot_config.json dosyasını kontrol et.")
        params["timestamp"] = int(time.time() * 1000)
        params["recvWindow"] = 5000
        payload = urllib.parse.urlencode(params)
        sig = hmac.new(cfg["api_secret"].encode(), payload.encode(), hashlib.sha256).hexdigest()
        params["signature"] = sig
        headers["X-MBX-APIKEY"] = cfg["api_key"]
    encoded = urllib.parse.urlencode(params)
    if method == "GET":
        url = base + path + (("?" + encoded) if encoded else "")
        data = None
    else:
        url = base + path
        data = encoded.encode()
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")
        raise RuntimeError(f"HTTP {e.code}: {detail[:350]}")
    except Exception as e:
        raise RuntimeError(f"Bağlantı hatası: {e}")
    if isinstance(result, dict) and "code" in result and result.get("code") not in (0, "0", None):
        raise RuntimeError(f"Binance TR API: {result.get('msg', result.get('message', result))}")
    return result

def market_data(cfg):
    symbol = cfg["symbol"].strip().upper()
    compact = symbol.replace("_", "")
    raw = request_json("/api/v3/ticker/price", {"symbol": compact}, base=MARKET_BASE)
    if not isinstance(raw, dict) or "price" not in raw:
        raise RuntimeError("Fiyat verisi okunamadı: " + str(raw)[:250])
    price = Decimal(str(raw["price"]))
    raw_candles = request_json("/api/v1/klines",
        {"symbol": compact, "interval": "1m", "limit": 30}, base=MARKET_BASE)
    candles = raw_candles.get("data", raw_candles) if isinstance(raw_candles, dict) else raw_candles
    if not isinstance(candles, list) or len(candles) < 15:
        raise RuntimeError("Mum verisi alınamadı: " + str(raw_candles)[:250])
    closes = [Decimal(str(c[4])) for c in candles]
    short_ma = sum(closes[-5:]) / Decimal(5)
    long_ma = sum(closes[-15:]) / Decimal(15)
    return price, short_ma, long_ma

def account(cfg):
    return request_json("/open/v1/account/spot", {}, signed=True, cfg=cfg)

def market_order(cfg, side, quote_tl=None, quantity=None):
    # Binance TR API: side 0=BUY, 1=SELL; type 2=MARKET.
    params = {"symbol": cfg["symbol"].strip().upper(),
              "side": "0" if side == "BUY" else "1",
              "type": "2"}
    if side == "BUY":
        params["quoteOrderQty"] = str(quote_tl)
    else:
        params["quantity"] = str(quantity)
    return request_json("/open/v1/orders", params, method="POST", signed=True, cfg=cfg)

def order_detail(cfg, order_id):
    return request_json("/open/v1/orders/detail", {"orderId": str(order_id)}, signed=True, cfg=cfg)

def unwrap_data(x):
    return x.get("data", x) if isinstance(x, dict) else x


def wait_order(cfg, order_id, attempts=8):
    detail = {}
    for _ in range(attempts):
        detail = unwrap_data(order_detail(cfg, order_id))
        if not isinstance(detail, dict):
            raise RuntimeError("Emir durumu okunamadı; Binance TR'den kontrol et.")
        try:
            status = int(detail.get("status", -99))
        except (TypeError, ValueError):
            status = -99
        if status in (2, 3, 5, 6):
            return detail
        time.sleep(1)
    return detail

def main():
    cfg = read_json(CONFIG_FILE, DEFAULT_CONFIG)
    for k, v in DEFAULT_CONFIG.items():
        cfg.setdefault(k, v)
    cfg["symbol"] = str(cfg.get("symbol", "BTC_TRY")).upper().strip()
    if not cfg.get("api_key") or not cfg.get("api_secret"):
        print("API bilgileri bot_config.json içinde eksik.")
        return
    try:
        min_tl, max_tl = Decimal(str(cfg["min_tl"])), Decimal(str(cfg["max_tl"]))
        trade_tl = Decimal(str(cfg["trade_tl"]))
        if min_tl < 50 or max_tl > 150 or min_tl > max_tl:
            raise ValueError("Min 50 TL, max 150 TL sınırında olmalı.")
        trade_tl = min(max(trade_tl, min_tl), max_tl)
    except Exception as e:
        print("Tutar ayarı hatalı:", e)
        return

    print("\n=== BINANCE TR OTOMATİK SPOT BOT ===")
    print("İşlem çifti:", cfg["symbol"], "| Alım tutarı:", trade_tl, "TL")
    print("Para çekme API'si kullanılmıyor. Bot yalnızca bu işlem çiftindeki kendi kaydettiği pozisyonu satmayı dener.")
    print("Strateji: 1 dakikalık mumlarda 5 ortalama / 15 ortalama kesişim farkı.")
    print("Bu basit strateji kâr garantisi vermez; gerçek para kaybedebilirsin.")
    if not cfg.get("live_trading", False):
        print("\nGÜVENLİ MOD açık. Önce yalnızca sinyal ve hesap bağlantısı test edilecek.")
        live = False
    else:
        answer = input("\nGERÇEK emir göndermek için aynen ISLEMLERI AC yaz: ").strip()
        live = answer == "ISLEMLERI AC"
        if not live:
            print("Gerçek emir kapalı bırakıldı.")
    state = read_json(STATE_FILE, {"position_qty": "0", "last_action": "none", "last_signal": "none"})
    try:
        acct = unwrap_data(account(cfg))
        if isinstance(acct, dict):
            print("Hesap API bağlantısı başarılı. canTrade =", acct.get("canTrade", "bilinmiyor"),
                  "| canWithdraw =", acct.get("canWithdraw", "bilinmiyor"))
        else:
            print("Hesap bağlantısı başarılı.")
    except Exception as e:
        print("Hesap API bağlantı hatası:", e)
        print("Bu hata çözülmeden gerçek işlem yapılmaz.")
        return

    interval = max(30, int(cfg.get("check_interval_seconds", 60)))
    buy_thr = Decimal(str(cfg.get("buy_threshold_percent", "0.10"))) / Decimal(100)
    sell_thr = Decimal(str(cfg.get("sell_threshold_percent", "0.10"))) / Decimal(100)
    print("Bot çalışıyor. Durdurmak için Ctrl+C.\n")
    while True:
        try:
            price, short_ma, long_ma = market_data(cfg)
            print("Kısa ortalama:", short_ma, "| Uzun ortalama:", long_ma, "| Fark %:", (short_ma / long_ma - 1) * 100)
            if short_ma > long_ma * (1 + buy_thr):
                signal = "BUY"
            elif short_ma < long_ma * (1 - sell_thr):
                signal = "SELL"
            else:
                signal = "HOLD"
            print(time.strftime("%H:%M:%S"), "| fiyat:", price, "| sinyal:", signal,
                  "| pozisyon:", state.get("position_qty", "0"))
            # Bekleyen emri her turda kontrol et; aynı anda ikinci emir gönderme.
            pending = state.get("pending_order_id")
            if live and pending:
                detail = unwrap_data(order_detail(cfg, pending))
                if not isinstance(detail, dict):
                    raise RuntimeError("Bekleyen emir okunamadı; yeni emir gönderilmeyecek.")
                status = int(detail.get("status", -99))
                executed = Decimal(str(detail.get("executedQty", "0")))
                side = state.get("pending_order_side")
                base_qty = Decimal(str(state.get("pending_base_qty", "0")))

                if side == "BUY":
                    state["position_qty"] = str(base_qty + executed)
                elif side == "SELL":
                    state["position_qty"] = str(max(base_qty - executed, Decimal("0")))

                if status in (2, 3, 5, 6):
                    state.pop("pending_order_id", None)
                    state.pop("pending_order_side", None)
                    state.pop("pending_base_qty", None)
                    print("Bekleyen emir sonuçlandı. Durum:", status,
                          "| Gerçekleşen:", executed)
                    if side == "SELL" and Decimal(state.get("position_qty", "0")) == 0:
                        state["last_action"] = "SELL"
                else:
                    print("Emir hâlâ bekliyor; yeni emir gönderilmiyor. Durum:", status)
                save_json(STATE_FILE, state)

            if live and not state.get("pending_order_id") and signal != state.get("last_signal"):
                qty = Decimal(str(state.get("position_qty", "0")))
                side = None
                base_qty = qty

                if signal == "BUY" and qty <= 0:
                    spend = min(max(trade_tl, min_tl), max_tl, Decimal("150"))
                    print("ALIM emri hazırlanıyor:", spend, "TL")
                    result = unwrap_data(market_order(cfg, "BUY", quote_tl=spend))
                    oid = result.get("orderId") if isinstance(result, dict) else None
                    if oid is None:
                        raise RuntimeError("Alım yanıtında orderId yok; emir geçmişini kontrol et.")
                    side = "BUY"
                    base_qty = qty

                elif signal == "SELL" and qty > 0:
                    print("Satış emri hazırlanıyor:", qty)
                    result = unwrap_data(market_order(cfg, "SELL", quantity=qty))
                    oid = result.get("orderId") if isinstance(result, dict) else None
                    if oid is None:
                        raise RuntimeError("Satış yanıtında orderId yok; emir geçmişini kontrol et.")
                    side = "SELL"
                    base_qty = qty

                if side:
                    state["pending_order_id"] = str(oid)
                    state["pending_order_side"] = side
                    state["pending_base_qty"] = str(base_qty)
                    state["last_signal"] = signal
                    save_json(STATE_FILE, state)

                    detail = wait_order(cfg, oid)
                    if not isinstance(detail, dict):
                        raise RuntimeError("Emir sonucu okunamadı; yeni emir gönderilmeyecek.")
                    status = int(detail.get("status", -99))
                    executed = Decimal(str(detail.get("executedQty", "0")))

                    if side == "BUY":
                        state["position_qty"] = str(base_qty + executed)
                    else:
                        state["position_qty"] = str(max(base_qty - executed, Decimal("0")))

                    if status in (2, 3, 5, 6):
                        state.pop("pending_order_id", None)
                        state.pop("pending_order_side", None)
                        state.pop("pending_base_qty", None)
                        if side == "SELL" and Decimal(state["position_qty"]) == 0:
                            state["last_action"] = "SELL"
                        elif side == "BUY" and executed > 0:
                            state["last_action"] = "BUY"
                        print("Emir sonucu:", status, "| Gerçekleşen miktar:", executed)
                    else:
                        print("Emir hâlâ bekliyor; takip için kayıt edildi:", oid)

                    save_json(STATE_FILE, state)
                else:
                    state["last_signal"] = signal
                    save_json(STATE_FILE, state)

            time.sleep(interval)
        except KeyboardInterrupt:
            print("\nBot durduruldu.")
            break
        except Exception as e:
            print("HATA:", e)
            print("Güvenlik için yeni emir denenmeyecek; 60 saniye sonra tekrar kontrol edilecek.")
            time.sleep(60)

if __name__ == "__main__":
    main()
