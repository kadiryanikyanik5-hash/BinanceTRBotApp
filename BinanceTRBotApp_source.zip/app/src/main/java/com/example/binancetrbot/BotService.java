
package com.example.binancetrbot;
import android.app.*; import android.content.*; import android.os.*; import java.io.*; import com.chaquo.python.*;
public class BotService extends Service {
 public void onCreate(){super.onCreate(); String channel="bot_running"; if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(channel,"Binance TR Bot",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);} Notification n=new Notification.Builder(this,channel).setContentTitle("Binance TR Bot çalışıyor").setContentText("Botu durdurmak için uygulamayı aç").setSmallIcon(android.R.drawable.ic_media_play).build(); startForeground(42,n); }
 public int onStartCommand(Intent i,int flags,int id){ new Thread(()->{ try { if(!Python.isStarted()) Python.start(new AndroidPlatform(this)); PyObject m=Python.getInstance().getModule("binance_tr_multi_bot"); String home=new File(getFilesDir(),"binancebot").getAbsolutePath(); m.callAttr("set_home",home); m.callAttr("main"); }catch(Throwable e){try{File f=new File(getFilesDir(),"binancebot/bot.log"); FileWriter w=new FileWriter(f,true);w.write("UYGULAMA HATASI: "+e+"\n");w.close();}catch(Exception ignored){}} stopSelf(); }).start(); return START_NOT_STICKY; }
 public void onDestroy(){super.onDestroy();} public IBinder onBind(Intent i){return null;}
}
