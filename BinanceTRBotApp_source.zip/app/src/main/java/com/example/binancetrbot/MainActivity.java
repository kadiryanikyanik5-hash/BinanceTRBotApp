
package com.example.binancetrbot;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  EditText key, secret, amount; CheckBox live; TextView status;
  File home, cfg, log; Handler handler = new Handler(Looper.getMainLooper());
  Runnable refresh = new Runnable(){ public void run(){ showLog(); handler.postDelayed(this,2500); }};
  public void onCreate(Bundle b){ super.onCreate(b); home=new File(getFilesDir(),"binancebot"); home.mkdirs(); cfg=new File(home,"bot_config.json"); log=new File(home,"bot.log");
    LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(28,24,28,20); root.setBackgroundColor(Color.rgb(247,248,250));
    ScrollView scroll=new ScrollView(this); LinearLayout content=new LinearLayout(this); content.setOrientation(1); scroll.addView(content);
    TextView title=new TextView(this); title.setText("BINANCE TR BOT"); title.setTextSize(25); title.setTextColor(Color.rgb(20,45,80)); title.setPadding(0,0,0,8); content.addView(title);
    TextView note=new TextView(this); note.setText("20 parite • 1 dakikalık ortalama stratejisi\nÖnce güvenli modda bağlantıyı kontrol et."); note.setTextSize(15); content.addView(note);
    key=field(content,"API Key",false); secret=field(content,"API Secret",true); amount=field(content,"İşlem tutarı (TL)",false); amount.setText("50");
    live=new CheckBox(this); live.setText("GERÇEK AL-SAT işlemlerine izin ver"); live.setTextColor(Color.RED); content.addView(live);
    TextView warning=new TextView(this); warning.setText("Uyarı: gerçek işlem para kaybettirebilir. Binance TR API anahtarında para çekme iznini kapat. Anahtarlar yalnızca bu telefonun uygulama alanında saklanır."); warning.setTextSize(13); content.addView(warning);
    Button save=new Button(this); save.setText("AYARLARI KAYDET"); content.addView(save); save.setOnClickListener(v->saveConfig());
    Button start=new Button(this); start.setText("BOTU BAŞLAT"); content.addView(start); start.setOnClickListener(v->{ if(saveConfig()){ if(live.isChecked()){ new AlertDialog.Builder(this).setTitle("Gerçek işlem onayı").setMessage("Bot gerçek alım-satım emirleri gönderebilir. Zarar riski var. Devam edilsin mi?").setNegativeButton("İptal",null).setPositiveButton("Gerçek işlemi aç",(d,w)->startBot()).show(); } else startBot(); }});
    Button stop=new Button(this); stop.setText("BOTU DURDUR"); content.addView(stop); stop.setOnClickListener(v->{ try { new File(home,"STOP").createNewFile(); }catch(Exception e){} stopService(new Intent(this,BotService.class)); status.setText("Durdurma isteği gönderildi."); });
    status=new TextView(this); status.setTextSize(14); status.setTextColor(Color.DKGRAY); status.setPadding(0,14,0,8); content.addView(status);
    TextView logTitle=new TextView(this); logTitle.setText("BOT KAYITLARI"); logTitle.setTextSize(18); content.addView(logTitle); TextView logs=new TextView(this); logs.setTextIsSelectable(true); logs.setTextSize(12); content.addView(logs);
    root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    try { if(cfg.exists()){ JSONObject j=new JSONObject(read(cfg)); key.setText(j.optString("api_key","")); secret.setText(j.optString("api_secret","")); amount.setText(j.optString("trade_tl","50")); live.setChecked(j.optBoolean("live_trading",false)); }}catch(Exception ignored){}
    handler.post(refresh);
  }
  EditText field(LinearLayout parent,String hint,boolean pw){ EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); if(pw)e.setInputType(129); parent.addView(e); return e; }
  boolean saveConfig(){ try{ double n=Double.parseDouble(amount.getText().toString().trim()); if(n<50||n>150){ toast("İşlem tutarı 50-150 TL aralığında olmalı."); return false;} if(key.getText().toString().trim().isEmpty()||secret.getText().toString().trim().isEmpty()){toast("API Key ve Secret gir.");return false;} JSONObject j=new JSONObject(); j.put("api_key",key.getText().toString().trim()); j.put("api_secret",secret.getText().toString().trim()); j.put("symbol","BTC_TRY"); j.put("trade_tl",amount.getText().toString().trim()); j.put("min_tl","50"); j.put("max_tl","150"); j.put("live_trading",live.isChecked()); j.put("check_interval_seconds",60); j.put("buy_threshold_percent","0.10"); j.put("sell_threshold_percent","0.10"); try(FileOutputStream o=new FileOutputStream(cfg)){o.write(j.toString(2).getBytes(StandardCharsets.UTF_8));} status.setText("Ayarlar kaydedildi."); return true;}catch(Exception e){toast("Kaydedilemedi: "+e.getMessage());return false;} }
  void startBot(){ new File(home,"STOP").delete(); try{ if(!log.exists())log.createNewFile(); }catch(Exception e){} startForegroundService(new Intent(this,BotService.class)); status.setText(live.isChecked()?"Bot başlatıldı • GERÇEK İŞLEM AÇIK":"Bot başlatıldı • güvenli mod"); }
  void showLog(){ try{ String s=read(log); TextView t=findLogText(); if(t!=null)t.setText(s.length()>12000?s.substring(s.length()-12000):s); }catch(Exception ignored){} }
  TextView findLogText(){ if(!( ((android.view.ViewGroup)((android.view.ViewGroup)findViewById(android.R.id.content)).getChildAt(0)).getChildAt(0) instanceof ScrollView)) return null; ScrollView sv=(ScrollView)((android.view.ViewGroup)findViewById(android.R.id.content)).getChildAt(0); LinearLayout c=(LinearLayout)sv.getChildAt(0); return (TextView)c.getChildAt(c.getChildCount()-1); }
  String read(File f)throws Exception{ byte[] b=java.nio.file.Files.readAllBytes(f.toPath()); return new String(b,StandardCharsets.UTF_8); }
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  public void onDestroy(){handler.removeCallbacks(refresh);super.onDestroy();}
}
